from userbot.Config import Config

RBOT = Config.TG_BOT_USERNAME
ROZA = Config.PRIVATE_GROUP_BOT_API_ID
StJms = [
    "▾∮ جـار اعـداد البـوت المسـاعد",
    "▾∮ يـتم اكمـال اعـداد البـوت االمسـاعد",
    "▾∮ تـم بنجاح اعـداد البـوت المسـاعد",
]
Stdec = "- MisTiri 𝖴𝖲𝖤𝖱𝖡𝖮𝖳 𝖠𝖲𝖲𝖨𝖳𝖠𝖭𝖳 \n- MisTiri 𝖥𝖮𝖱  {}\n- @UX4SL "
SetAbt = "- MisTiri 𝖴𝖲𝖤𝖱𝖡𝖮𝖳\n- MisTiri 𝖥𝖮𝖱  {}"
