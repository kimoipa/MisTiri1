# @Jmthon - < https://t.me/Jmthon >
# Copyright (C) 2021 - JMTHON-AR
# All rights reserved.
#
# This file is a part of < https://github.com/JMTHON-AR/JMTHON >
# Please read the GNU Affero General Public License in;
# < https://github.com/JMTHON-AR/JM-THON/blob/master/LICENSE
# ===============================================================
from .decorators import check_owner

CMD_INFO = {}
PLG_INFO = {}
GRP_INFO = {}
BOT_INFO = []
LOADED_CMDS = {}
