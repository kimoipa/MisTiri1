# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━#
B = (
    "- [SOURCE MisTiri - 𝖠𝖭𝖨𝖬𝖤 𝖦𝖨𝖥](t.me/UX4SL) \n\n"
    "**⌔∮ قائـمه متحـركات الانمي :**\n\n"
    "- `.متحركات ولد`"
)

gifrz_1 = "https://t.me/GiFO8/5"
gifrz_2 = "https://t.me/GiFO8/6"
gifrz_3 = "https://t.me/GiFO8/7"
gifrz_4 = "https://t.me/GiFO8/8"
gifrz_5 = "https://t.me/GiFO8/9"
gifrz_6 = "https://t.me/GiFO8/10"
gifrz_7 = "https://t.me/GiFO8/11"
gifrz_8 = "https://t.me/GiFO8/12"
gifrz_9 = "https://t.me/GiFO8/13"
gifrz_10 = "https://t.me/GiFO8/14"
gifrz_11 = "https://t.me/GiFO8/15"
gifrz_12 = "https://t.me/GiFO8/16"

ROZG = (
    "- [SOURCE MisTiri - 𝖠𝖭𝖨𝖬𝖤 𝖦𝖨𝖥](t.me/UX4SL) \n\n"
    "**⌔∮ قائـمه المتحـركات :**\n\n"
    "- `.و1`\n"
    "- `.و2`\n"
    "- `.و3`\n"
    "- `.و4`\n"
    "- `.و5`\n"
    "- `.و6`\n"
    "- `.و7`\n"
    "- `.و8`\n"
    "- `.و9`\n"
    "- `.و10`\n"
    "- `.و11`\n"
    "- `.و12`\n"
    "- [SOURCE MisiTiri](t.me/UX4SL) \n\n"
)
