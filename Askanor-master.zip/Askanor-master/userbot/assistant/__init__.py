from Jmthon.razan.resources.assistant import *
from userbot import BOTLOG, BOTLOG_CHATID, jmthon

from ..Config import Config
from ..core.inlinebot import *

# Jmthon
